/**
 * Name : Anchal Singh
 * Class : CS501 WS4
 * Project 3 description:A Java program that will go through the first step of encrypting an input file and writing the encrypted contents to an output file. 
 */

import java.io.IOException;

public class DriverMain {

	public static void main(String[] args) throws IOException {
		System.out.println("Encryption Level 1");
		System.out.println();
		
		
		//Variables for file names
		String inFName = "Oct1.txt";;
		String outFName = "EncryptedOct1.txt";
		
		//Creates Encryption class object
		Driver encrypt = new Driver(outFName);
		
		//Reads input file and opens it
		System.out.println("Opening input file....");
		System.out.println();
		
		encrypt.readFile(inFName);
		
		//Encrypting
		System.out.println("Encrypting....");
		System.out.println();
		
		encrypt.encrypt();
		
		//Encryption complete
		encrypt.close();
		System.out.println("Encryption complete.");
		System.out.println();
		
		System.out.println("End of program.");

		//Program ends
	}

}
