
/**
 * Name : Anchal Singh
 * Class : CS501 WS4
 * Project 3 description: A Java program that will go through the first step of encrypting an input file and writing the encrypted contents to an output file. 
 */

import java.io.File;
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;


public class Driver {
	
	//Variables	for the program
	private Scanner inF;       //input file
	private PrintWriter outF;  //output file
	private File File1;        //file
	
	
	//Constructor for the program
	public Driver(String FName) throws IOException {
		outF = new PrintWriter(FName);}
	
	//This method will read in from the input file
	public void readFile(String FName) throws IOException {
		File1 = new File(FName);
		inF = new Scanner(File1);
	 }         //End readFile
	
	
	//Encrypting the file
	public void encrypt() {
		while (inF.hasNext()) {
			String text = inF.nextLine();
			String EncryptedText = EncryptText(text);
			if (inF.hasNext()) {
				outF.println(EncryptedText);
			}
			else {
				outF.print(EncryptedText);
			}
		}
	}
	
	//Now Encrypting the text
	private String EncryptText(String text) {
		String enc = "";
		
		for (int i = 0; i < text.length(); i++) {
			char Letter = text.charAt(i);
			
		 if (Character.isLetter(Letter)) {
			if (Character.isUpperCase(Letter)) {
				Letter = Character.toLowerCase(Letter);
				}
			else {
				Letter = Character.toUpperCase(Letter);
				}
				
	//Shift character by adding 3 (A = d, z = C, etc..)
	int ascii = (int) Letter;
	    ascii += 3;
				
    //Checking whether ASCII is out of range 
				if (90 < ascii & ascii < 97) {
					int difs = ascii - 90;
					ascii = 64 + difs;
					enc += (char) ascii;
				}
				else if(ascii > 122) {
					int difs = ascii - 122;
					ascii = 96 + difs;
					enc += (char) ascii;
				}
				else {
					enc += (char) ascii;
				}				
				
			}
			   else {
				enc += Letter;
			}
		
		}   	
		return enc;}
	
	
	//Close the file
	public void close() {
		outF.close();    //Output closed
		inF.close();     //Input closed
	}
 
}
