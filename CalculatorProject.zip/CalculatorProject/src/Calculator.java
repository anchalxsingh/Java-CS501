//Anchal Singh
//CS 501 Section 4

public class Calculator {
	
	//variables
	private double value;
	
	//constructor
	public Calculator() {
		value = 0;
	}
	
	//add   
    public void add(double val) {
	    value = value + val;
	}
	    
    //subtract  
	public void subtract(double val)  {
   	    value = value - val;
	   }
	
	//multiply
	public void multiply(double val)  {
    	value = value * val;  
	   }
	
    //divide
	public void divide(double val)  {
		value = value / val;
	   }
	
	 //get values  
	public double getValue() {
		return value;
	   
	}
	
	public void clear() {
		value=0;   
	}	   
}
	   