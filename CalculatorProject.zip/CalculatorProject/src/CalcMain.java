//Anchal Singh
//CS 501 Section 4

import java.util.Scanner;
public class CalcMain {

	public static void main(String[] args) {
		
	//variables
	double num1;
	double num2;
	final int multi = 3;
	final int divi = 2; 
	
	//scanner
	Scanner scanObj = new Scanner(System.in);
	System.out.println("The Calculator Program \n");
	
	System.out.print("Enter the first number:");
  num1 = scanObj.nextDouble();
	
	System.out.print("Enter the second number:");
  num2 = scanObj.nextDouble();
	
	//constructor
	Calculator calcObj = new Calculator();

	//call
	System.out.println("\n \nOutput: \n \n");
	System.out.println(calcObj.getValue());
	
	//display
	
	calcObj.add(num1);
	System.out.println(String.format("%.1f", calcObj.getValue()));
	
	calcObj.multiply(multi);
	System.out.println(String.format("%.1f", calcObj.getValue()));
	
	calcObj.subtract(num2);
	System.out.println(String.format("%.1f", calcObj.getValue()));
	
	calcObj.divide(divi);
	System.out.println(String.format("%.1f", calcObj.getValue()));
	
	calcObj.clear();
	System.out.println(String.format("%.1f", calcObj.getValue()));
	
	System.out.print("\nEnd of results.");
	
	scanObj.close();
	
	System.exit(0);
		}	
}
